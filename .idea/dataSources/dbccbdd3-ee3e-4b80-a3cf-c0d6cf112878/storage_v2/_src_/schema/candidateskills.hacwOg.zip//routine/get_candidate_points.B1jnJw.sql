create
    definer = root@localhost procedure get_candidate_points(IN p_candidate_id int)
BEGIN
    SELECT SUM(CASE WHEN skill_ID = 2 OR skill_ID = 3 THEN 2
                    WHEN skill_ID = 9 OR skill_ID = 10 THEN 3 ELSE 1 END )
               AS
               Points
    FROM candidate_skill
    WHERE candidate_ID = p_candidate_id;
END;

