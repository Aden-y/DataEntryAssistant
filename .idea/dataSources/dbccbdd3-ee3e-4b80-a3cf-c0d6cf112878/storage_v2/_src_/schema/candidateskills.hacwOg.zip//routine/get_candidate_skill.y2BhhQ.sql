create
    definer = root@localhost procedure get_candidate_skill(IN p_candidate_id int)
BEGIN
    SELECT candidate.candidate_ID AS 'ID',
           concat(lastName,', ', firstName) as 'Candidate_Name',
           group_concat(skills.skill separator' | ') AS 'Skill'
    From candidate JOIN candidate_skill USING(candidate_ID)
                   JOIN skills USING(skill_ID)
    WHERE candidate.candidate_ID = p_candidate_id
    GROUP BY candidate.candidate_ID;
END;

